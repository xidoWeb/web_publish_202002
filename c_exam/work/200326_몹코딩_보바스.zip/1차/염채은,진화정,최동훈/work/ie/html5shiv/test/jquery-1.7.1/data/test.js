var foobar = "bar";
jQuery('#ap').html('bar');
ok( true, "test.js executed");
